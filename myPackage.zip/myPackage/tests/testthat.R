library(testthat)
library(myPackage)

test_check("myPackage")
