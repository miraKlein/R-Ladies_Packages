#' Say hello
#' @description Blub
#' @param who character: who is greeted
#' @examples hello("Julia!")
#' @export
hello <- function(who) {
  paste0("Hello ", who, "!")
}
