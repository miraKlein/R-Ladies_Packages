#' @title Plot histogram from simulation
#' @description Plot a histogram for normally distributed simulated random values
#' @param sampleSize integer: Number of rows in the data
#' @importFrom ggplot2 ggplot geom_histogram aes_string
#' @importFrom stats rnorm
#' @export
histoNormGg <- function(sampleSize) {
  dat <- data.frame(var1 = rnorm(n = sampleSize))
  ggplot(dat) +
    geom_histogram(aes_string("var1"),
                   colour = NA,
                   binwidth = 0.5)
}
